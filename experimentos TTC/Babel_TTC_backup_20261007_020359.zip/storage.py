"""
Interface de armazenamento e backend de disco local.
"""

import os
import hashlib
import zlib
import tempfile
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Tuple


class StorageBackend(ABC):
    """Interface abstrata para backends de armazenamento."""

    @abstractmethod
    def write(self, path: str, data: bytes) -> None:
        """Escreve dados de forma atômica."""
        pass

    @abstractmethod
    def read(self, path: str) -> bytes:
        """Lê dados."""
        pass

    @abstractmethod
    def exists(self, path: str) -> bool:
        """Verifica se existe."""
        pass

    @abstractmethod
    def delete(self, path: str) -> None:
        """Remove arquivo."""
        pass

    @abstractmethod
    def size(self, path: str) -> int:
        """Retorna tamanho em bytes."""
        pass

    @abstractmethod
    def list_files(self, directory: str) -> list:
        """Lista arquivos em diretório."""
        pass


class LocalDiskStorage(StorageBackend):
    """Backend de disco local com gravação atômica."""

    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)

    def _full_path(self, path: str) -> Path:
        return self.base_path / path

    def write(self, path: str, data: bytes) -> None:
        """
        Grava de forma atômica: escreve em temporário e renomeia.
        """
        full_path = self._full_path(path)
        full_path.parent.mkdir(parents=True, exist_ok=True)

        # Cria arquivo temporário no mesmo diretório
        fd, tmp_path = tempfile.mkstemp(
            dir=str(full_path.parent),
            prefix=f".tmp_{full_path.name}_"
        )
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            # Rename atômico
            os.replace(tmp_path, str(full_path))
        except:
            # Limpa temporário em caso de erro
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    def read(self, path: str) -> bytes:
        full_path = self._full_path(path)
        with open(full_path, 'rb') as f:
            return f.read()

    def exists(self, path: str) -> bool:
        return self._full_path(path).exists()

    def delete(self, path: str) -> None:
        full_path = self._full_path(path)
        if full_path.exists():
            full_path.unlink()

    def size(self, path: str) -> int:
        return self._full_path(path).stat().st_size

    def list_files(self, directory: str) -> list:
        full_dir = self._full_path(directory)
        if not full_dir.exists():
            return []
        return [str(f.relative_to(self.base_path)) for f in full_dir.rglob('*') if f.is_file()]

    def store_file_streaming(self, source_path: str, dest_dir: str,
                             chunk_size: int = 1024 * 1024) -> Tuple[str, int, bool, str]:
        """
        Armazena arquivo com streaming real: lê em blocos, atualiza SHA-256
        e comprime incrementalmente sem carregar o arquivo inteiro na memória.

        O conteúdo comprimido é salvo em <dest_dir>/payloads/<content_hash>.
        Não há mais pasta hashes/.

        Retorna: (content_hash, compressed_size, already_existed, final_path)
        """
        import os
        hasher = hashlib.sha256()
        compressor = zlib.compressobj(6)
        compressed_size = 0

        # Cria diretório de payloads dentro de dest_dir
        payload_dir = self._full_path(os.path.join(dest_dir, "payloads"))
        payload_dir.mkdir(parents=True, exist_ok=True)

        # Cria arquivo temporário no payload_dir
        fd, tmp_path = tempfile.mkstemp(
            dir=str(payload_dir),
            prefix=".tmp_"
        )

        try:
            with open(source_path, 'rb') as src:
                with os.fdopen(fd, 'wb') as tmp:
                    while True:
                        chunk = src.read(chunk_size)
                        if not chunk:
                            break
                        hasher.update(chunk)
                        compressed_chunk = compressor.compress(chunk)
                        tmp.write(compressed_chunk)
                        compressed_size += len(compressed_chunk)

                    # Finaliza compressão
                    final_chunk = compressor.flush()
                    tmp.write(final_chunk)
                    compressed_size += len(final_chunk)
                    tmp.flush()
                    os.fsync(tmp.fileno())

            content_hash = hasher.hexdigest()

            # Caminho final dentro de payloads/
            final_path = os.path.join(payload_dir, content_hash)
            final_path_full = self._full_path(final_path)

            # Verifica se já existe
            if os.path.exists(final_path_full):
                # Descarta temporário
                os.unlink(tmp_path)
                return (content_hash, compressed_size, True, "")

            # Renomeia temporário para destino final
            os.replace(tmp_path, final_path_full)

            return (content_hash, compressed_size, False, final_path)

        except:
            # Limpa temporário em caso de erro
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise