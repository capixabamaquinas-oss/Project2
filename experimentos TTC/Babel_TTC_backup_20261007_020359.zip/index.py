"""
Índice SQLite — armazena aliases e metadados (sem payloads).
"""

import sqlite3
import os
from pathlib import Path
from typing import Optional, List, Tuple
from .compression import decompress


class BabelIndex:
    """Índice SQLite para o sistema Babel."""

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """Inicializa o esquema do banco."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    content_hash TEXT UNIQUE NOT NULL,
                    hexagon INTEGER NOT NULL,
                    wall INTEGER NOT NULL,
                    shelf INTEGER NOT NULL,
                    volume INTEGER NOT NULL,
                    page INTEGER NOT NULL,
                    original_size INTEGER NOT NULL,
                    compressed_size INTEGER NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS aliases (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE NOT NULL,
                    content_hash TEXT NOT NULL,
                    FOREIGN KEY (content_hash) REFERENCES items(content_hash)
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_aliases_hash
                ON aliases(content_hash)
            """)
            conn.commit()
        finally:
            conn.close()

    def add_item(self, content_hash: str, hexagon: int, wall: int,
                 shelf: int, volume: int, page: int,
                 original_size: int, compressed_size: int) -> bool:
        """
        Adiciona item ao índice. Retorna True se adicionou, False se já existia.
        """
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                INSERT INTO items (content_hash, hexagon, wall, shelf, volume, page,
                                   original_size, compressed_size)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (content_hash, hexagon, wall, shelf, volume, page,
                  original_size, compressed_size))
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            # Hash já existe — deduplicação
            return False
        finally:
            conn.close()

    def add_alias(self, path: str, content_hash: str) -> None:
        """Adiciona alias (caminho) para um conteúdo."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                INSERT OR IGNORE INTO aliases (path, content_hash)
                VALUES (?, ?)
            """, (path, content_hash))
            conn.commit()
        finally:
            conn.close()

    def get_by_hash(self, content_hash: str) -> Optional[Tuple]:
        """Recupera item pelo hash."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute(
                "SELECT * FROM items WHERE content_hash = ?",
                (content_hash,)
            )
            return cursor.fetchone()
        finally:
            conn.close()

    def get_by_path(self, path: str) -> Optional[Tuple]:
        """Recupera item pelo caminho (alias)."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute("""
                SELECT i.* FROM items i
                JOIN aliases a ON i.content_hash = a.content_hash
                WHERE a.path = ?
            """, (path,))
            return cursor.fetchone()
        finally:
            conn.close()

    def get_payload(self, content_hash: str) -> Optional[bytes]:
        """Recupera e descomprime o payload a partir do arquivo payloads/<hash>."""
        # O índice está dentro do diretório do pacote; os payloads ficam em ../payloads/<hash>
        payload_dir = os.path.join(os.path.dirname(self.db_path), "payloads")
        payload_path = os.path.join(payload_dir, content_hash)
        if not os.path.exists(payload_path):
            return None
        with open(payload_path, 'rb') as f:
            compressed = f.read()
        return decompress(compressed)

    def list_all(self) -> List[Tuple]:
        """Lista todos os itens."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute("SELECT * FROM items")
            return cursor.fetchall()
        finally:
            conn.close()

    def count_items(self) -> int:
        """Conta itens únicos."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute("SELECT COUNT(*) FROM items")
            return cursor.fetchone()[0]
        finally:
            conn.close()

    def count_aliases(self) -> int:
        """Conta aliases."""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.execute("SELECT COUNT(*) FROM aliases")
            return cursor.fetchone()[0]
        finally:
            conn.close()

    def vacuum(self) -> None:
        """Compacta o banco de dados."""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("VACUUM")
            conn.commit()
        finally:
            conn.close()

    def merge(self, other_db_path: str) -> int:
        """
        Mescla outro índice neste. Retorna número de itens adicionados.
        """
        added = 0
        conn = sqlite3.connect(self.db_path)
        other_conn = sqlite3.connect(other_db_path)
        try:
            cursor = other_conn.execute("SELECT * FROM items")
            for row in cursor:
                try:
                    conn.execute("""
                        INSERT INTO items (content_hash, hexagon, wall, shelf, volume, page,
                                           original_size, compressed_size)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, row[1:])
                    added += 1
                except sqlite3.IntegrityError:
                    pass  # Já existe

            # Mescla aliases
            cursor = other_conn.execute("SELECT * FROM aliases")
            for row in cursor:
                conn.execute("""
                    INSERT OR IGNORE INTO aliases (path, content_hash)
                    VALUES (?, ?)
                """, row[1:])

            conn.commit()
        finally:
            conn.close()
            other_conn.close()
        return added