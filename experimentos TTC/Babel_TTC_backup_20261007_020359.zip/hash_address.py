"""
Hash e Endereço — SHA-256 e localizador derivado do hash.
"""

import hashlib
from typing import Tuple

# Capacidade experimental: 100 páginas/volume, 100 volumes/estante,
# 100 estantes/parede, 100 paredes/hexágono
PAGES_PER_VOLUME = 100
VOLUMES_PER_SHELF = 100
SHELVES_PER_WALL = 100
WALLS_PER_HEXAGON = 100


def compute_hash(data: bytes) -> str:
    """Computa SHA-256 do conteúdo."""
    return hashlib.sha256(data).hexdigest()


def compute_address(content_hash: str, hexagon: int = 0, wall: int = 0, shelf: int = 0,
                    volume: int = 0, page: int = 0) -> str:
    """
    Monta o endereço no formato BABEL://sha256:<hash>.
    Os parâmetros de coordenadas são ignorados mantidos apenas para compatibilidade.
    """
    return f"BABEL://sha256:{content_hash}"


def parse_address(address: str) -> Tuple[str, int, int, int, int, int]:
    """Faz parse de um endereço hierárquico (mantido para compatibilidade)."""
    parts = address.split(":")
    if len(parts) != 2:
        raise ValueError(f"Endereço inválido: {address}")
    content_hash = parts[0]
    coords = parts[1].split("/")
    if len(coords) != 5:
        raise ValueError(f"Coordenadas inválidas: {address}")
    return (content_hash, int(coords[0]), int(coords[1]),
            int(coords[2]), int(coords[3]), int(coords[4]))


def hash_to_index(content_hash: str) -> int:
    """
    Converte um hash SHA-256 em um índice determinístico.
    Usa os primeiros 16 caracteres do hash como número hexadecimal.
    """
    # Pegue os primeiros 16 caracteres do hash (64 bits) e converta para inteiro
    return int(content_hash[:16], 16)


def assign_coordinates(content_hash: str) -> Tuple[int, int, int, int, int]:
    """
    Atribui coordenadas hierárquicas deterministicamente a partir do hash.
    O mesmo hash sempre produz as mesmas coordenadas.

    Retorna: (hexagon, wall, shelf, volume, page)
    """
    index = hash_to_index(content_hash)
    page = index % PAGES_PER_VOLUME
    volume = (index // PAGES_PER_VOLUME) % VOLUMES_PER_SHELF
    shelf = (index // (PAGES_PER_VOLUME * VOLUMES_PER_SHELF)) % SHELVES_PER_WALL
    wall = (index // (PAGES_PER_VOLUME * VOLUMES_PER_SHELF * SHELVES_PER_WALL)) % WALLS_PER_HEXAGON
    hexagon = index // (PAGES_PER_VOLUME * VOLUMES_PER_SHELF * SHELVES_PER_WALL * WALLS_PER_HEXAGON)
    return (hexagon, wall, shelf, volume, page)