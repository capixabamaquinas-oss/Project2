"""
Pacote .babel — exportar, importar e mesclar.
"""

import os
import json
import zipfile
import tempfile
import shutil
from pathlib import Path
from typing import Optional
from .index import BabelIndex
from .compression import compress, decompress


class BabelPackage:
    """Gerencia pacotes .babel (arquivos zip com índice SQLite)."""

    def __init__(self, package_path: str):
        self.package_path = package_path
        self.index: Optional[BabelIndex] = None

    def create(self) -> None:
        """Cria novo pacote vazio."""
        self.index = BabelIndex(self.package_path)

    def open(self) -> None:
        """Abre pacote existente."""
        if not os.path.exists(self.package_path):
            raise FileNotFoundError(f"Pacote não encontrado: {self.package_path}")
        self.index = BabelIndex(self.package_path)

    def export(self, output_path: str) -> None:
        """
        Exporta pacote como arquivo .babel (zip com índice + metadados + payloads).
        """
        if self.index is None:
            raise RuntimeError("Nenhum pacote aberto")

        package_dir = os.path.dirname(self.index.db_path)
        payloads_dir = os.path.join(package_dir, "payloads")

        with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            # Adiciona o banco SQLite
            zf.write(self.index.db_path, 'index.sqlite')

            # Adiciona metadados
            metadata = {
                'version': '1.0.0',
                'items': self.index.count_items(),
                'aliases': self.index.count_aliases()
            }
            zf.writestr('metadata.json', json.dumps(metadata, indent=2))

            # Adiciona payloads, se existir
            if os.path.isdir(payloads_dir):
                for root, dirs, files in os.walk(payloads_dir):
                    for file in files:
                        file_path = os.path.join(root, file)
                        # Caminho relativo ao diretório do pacote
                        rel_path = os.path.relpath(file_path, package_dir)
                        zf.write(file_path, rel_path)

    def import_package(self, package_path: str, merge: bool = False) -> int:
        """
        Importa pacote .babel. Retorna número de itens importados.
        Se merge=True, mescla com o pacote atual.
        """
        if not os.path.exists(package_path):
            raise FileNotFoundError(f"Pacote não encontrado: {package_path}")

        with tempfile.TemporaryDirectory() as tmpdir:
            # Extrai com segurança (proteção contra zip slip)
            with zipfile.ZipFile(package_path, 'r') as zf:
                for member in zf.namelist():
                    # Verifica zip slip
                    target_path = os.path.join(tmpdir, member)
                    abs_target = os.path.abspath(target_path)
                    abs_tmpdir = os.path.abspath(tmpdir)
                    if not abs_target.startswith(abs_tmpdir):
                        raise ValueError(f"Caminho suspeito no pacote: {member}")
                zf.extractall(tmpdir)

            # Abre o índice extraído
            extracted_db = os.path.join(tmpdir, 'index.sqlite')
            if not os.path.exists(extracted_db):
                raise ValueError("Pacote inválido: index.sqlite não encontrado")

            imported_index = BabelIndex(extracted_db)

            if merge and self.index is not None:
                # Mescla com pacote atual
                added = self.index.merge(extracted_db)
                # Também mescla payloads: copia o diretório de payloads extraído para o diretório de payloads atual
                extracted_payloads_dir = os.path.join(tmpdir, 'payloads')
                package_dir = os.path.dirname(self.index.db_path)
                payloads_dir = os.path.join(package_dir, "payloads")
                if os.path.isdir(extracted_payloads_dir):
                    # Copia arquivos, sobrescrevendo se já existirem
                    for root, dirs, files in os.walk(extracted_payloads_dir):
                        for file in files:
                            src_path = os.path.join(root, file)
                            rel_path = os.path.relpath(src_path, extracted_payloads_dir)
                            dst_path = os.path.join(payloads_dir, rel_path)
                            os.makedirs(os.path.dirname(dst_path), exist_ok=True)
                            shutil.copy2(src_path, dst_path)
                return added
            else:
                # Substitui
                self.index = imported_index
                # Copia payloads extraído para o diretório de payloads do pacote
                extracted_payloads_dir = os.path.join(tmpdir, 'payloads')
                package_dir = os.path.dirname(self.index.db_path)
                payloads_dir = os.path.join(package_dir, "payloads")
                if os.path.isdir(extracted_payloads_dir):
                    # Remove o diretório de payloads atual se existir (pois vamos substituir)
                    if os.path.exists(payloads_dir):
                        shutil.rmtree(payloads_dir)
                    # Copia o diretório de payloads extraído
                    shutil.copytree(extracted_payloads_dir, payloads_dir)
                elif os.path.exists(payloads_dir):
                    # Se não há payloads extraídos, remove o diretório de payloads atual
                    shutil.rmtree(payloads_dir)
                return imported_index.count_items()

    def merge_packages(self, other_package_path: str) -> int:
        """Mescla outro pacote .babel neste."""
        return self.import_package(other_package_path, merge=True)