"""
Validador de integridade — verifica hashes e detecta corrupção.
"""

import hashlib
import os
from typing import Tuple, List
from .index import BabelIndex
from .compression import decompress


def validate_package(index: BabelIndex) -> Tuple[bool, List[str]]:
    """
    Valida integridade de todos os itens no pacote.

    Retorna: (válido, lista_de_erros)
    """
    errors = []
    items = index.list_all()

    for item in items:
        content_hash = item[1]
        original_size = item[7]
        compressed_size = item[8]

        # Localiza o payload no sistema de arquivos
        payload_dir = os.path.join(os.path.dirname(index.db_path), "payloads")
        payload_path = os.path.join(payload_dir, content_hash)
        if not os.path.exists(payload_path):
            errors.append(f"Hash {content_hash[:16]}...: payload não encontrado")
            continue

        # Lê o payload comprimido
        with open(payload_path, 'rb') as f:
            compressed = f.read()

        # Verifica tamanho comprimido
        if len(compressed) != compressed_size:
            errors.append(
                f"Hash {content_hash[:16]}...: tamanho comprimido mismatch "
                f"({len(compressed)} != {compressed_size})"
            )
            continue

        # Descomprime e verifica hash
        try:
            payload = decompress(compressed)
        except Exception as e:
            errors.append(
                f"Hash {content_hash[:16]}...: falha ao descomprimir: {e}"
            )
            continue

        # Verifica tamanho original
        if len(payload) != original_size:
            errors.append(
                f"Hash {content_hash[:16]}...: tamanho original mismatch "
                f"({len(payload)} != {original_size})"
            )
            continue

        # Verifica hash
        computed_hash = hashlib.sha256(payload).hexdigest()
        if computed_hash != content_hash:
            errors.append(
                f"Hash {content_hash[:16]}...: conteúdo corrompido "
                f"(hash esperado: {computed_hash[:16]}...)"
            )

    return (len(errors) == 0, errors)


def verify_file(index: BabelIndex, path: str) -> Tuple[bool, Optional[str]]:
    """
    Verifica integridade de um arquivo específico.

    Retorna: (válido, mensagem_de_erro)
    """
    item = index.get_by_path(path)
    if item is None:
        return (False, f"Arquivo não encontrado: {path}")

    content_hash = item[1]
    payload = index.get_payload(content_hash)

    if payload is None:
        return (False, f"Falha ao recuperar payload: {path}")

    computed_hash = hashlib.sha256(payload).hexdigest()
    if computed_hash != content_hash:
        return (False, f"Conteúdo corrompido: {path}")

    return (True, None)