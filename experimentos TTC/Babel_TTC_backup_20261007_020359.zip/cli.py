"""
CLI — Interface de linha de comando para Babel V1.

Comandos: add, get, verify, export, import
"""

import argparse
import sys
import os
from pathlib import Path
from .index import BabelIndex
from .package import BabelPackage
from .validator import validate_package, verify_file
from .hash_address import compute_hash, compute_address, assign_coordinates
from .compression import compress, decompress


def cmd_add(args):
    """Adiciona arquivo ao pacote."""
    pkg = BabelPackage(args.package)
    pkg.open()

    file_path = args.file

    # Usa streaming real: lê em blocos, atualiza hash e comprime incrementalmente
    from .storage import LocalDiskStorage
    storage = LocalDiskStorage(os.path.dirname(args.package) or '.')

    # Armazena com streaming
    content_hash, compressed_size, already_existed, payload_path = storage.store_file_streaming(
        file_path, "payloads"
    )

    # Verifica se já existe (deduplicação)
    existing = pkg.index.get_by_hash(content_hash)
    if existing or already_existed:
        # Só adiciona alias
        pkg.index.add_alias(args.path or file_path, content_hash)
        print(f"Arquivo já existe (deduplicado): {content_hash[:16]}...")
        print(f"Alias adicionado: {args.path or file_path}")
        return

    # Atribui coordenadas deterministicamente a partir do hash
    hexagon, wall, shelf, volume, page = assign_coordinates(content_hash)

    # Adiciona ao índice (sem payload)
    pkg.index.add_item(
        content_hash, hexagon, wall, shelf, volume, page,
        os.path.getsize(file_path), compressed_size
    )
    pkg.index.add_alias(args.path or file_path, content_hash)

    address = compute_address(content_hash, hexagon, wall, shelf, volume, page)
    print(f"Arquivo adicionado: {file_path}")
    print(f"Hash: {content_hash}")
    print(f"Endereço: {address}")
    print(f"Tamanho original: {os.path.getsize(file_path)} bytes")
    print(f"Tamanho comprimido: {compressed_size} bytes")


def cmd_get(args):
    """Recupera arquivo do pacote."""
    pkg = BabelPackage(args.package)
    pkg.open()

    # Tenta por caminho primeiro, depois por hash
    item = pkg.index.get_by_path(args.address)
    if item is None:
        # Tenta como hash
        item = pkg.index.get_by_hash(args.address)

    if item is None:
        print(f"Erro: endereço não encontrado: {args.address}", file=sys.stderr)
        sys.exit(1)

    content_hash = item[1]
    payload = pkg.index.get_payload(content_hash)

    if args.output:
        with open(args.output, 'wb') as f:
            f.write(payload)
        print(f"Arquivo recuperado: {args.output}")
    else:
        # Escreve para stdout (modo binário)
        sys.stdout.buffer.write(payload)


def cmd_verify(args):
    """Verifica integridade do pacote."""
    pkg = BabelPackage(args.package)
    pkg.open()

    if args.file:
        # Verifica arquivo específico
        valid, error = verify_file(pkg.index, args.file)
        if valid:
            print(f"OK: {args.file}")
        else:
            print(f"ERRO: {error}", file=sys.stderr)
            sys.exit(1)
    else:
        # Verifica pacote inteiro
        valid, errors = validate_package(pkg.index)
        if valid:
            print(f"Pacote íntegro: {pkg.index.count_items()} itens, {pkg.index.count_aliases()} aliases")
        else:
            print(f"ERRO: {len(errors)} problemas encontrados:", file=sys.stderr)
            for err in errors:
                print(f"  - {err}", file=sys.stderr)
            sys.exit(1)


def cmd_export(args):
    """Exporta pacote como arquivo .babel."""
    pkg = BabelPackage(args.package)
    pkg.open()
    pkg.export(args.output)
    print(f"Pacote exportado: {args.output}")


def cmd_import(args):
    """Importa pacote .babel."""
    pkg = BabelPackage(args.package)

    if args.merge:
        pkg.open()
        count = pkg.merge_packages(args.input)
        print(f"Mesclados {count} itens de {args.input}")
    else:
        pkg.create()
        count = pkg.import_package(args.input, merge=False)
        print(f"Importados {count} itens de {args.input}")


def main():
    parser = argparse.ArgumentParser(description='Babel V1 — Sistema de armazenamento')
    parser.add_argument('--package', '-p', required=True, help='Caminho do pacote SQLite')

    subparsers = parser.add_subparsers(dest='command', help='Comando')

    # add
    add_parser = subparsers.add_parser('add', help='Adiciona arquivo')
    add_parser.add_argument('file', help='Arquivo a adicionar')
    add_parser.add_argument('--path', help='Caminho lógico no pacote')

    # get
    get_parser = subparsers.add_parser('get', help='Recupera arquivo')
    get_parser.add_argument('address', help='Endereço ou hash')
    get_parser.add_argument('--output', '-o', help='Arquivo de saída')

    # verify
    verify_parser = subparsers.add_parser('verify', help='Verifica integridade')
    verify_parser.add_argument('--file', help='Verificar arquivo específico')

    # export
    export_parser = subparsers.add_parser('export', help='Exporta pacote')
    export_parser.add_argument('output', help='Arquivo .babel de saída')

    # import
    import_parser = subparsers.add_parser('import', help='Importa pacote')
    import_parser.add_argument('input', help='Arquivo .babel de entrada')
    import_parser.add_argument('--merge', action='store_true', help='Mesclar com pacote atual')

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    commands = {
        'add': cmd_add,
        'get': cmd_get,
        'verify': cmd_verify,
        'export': cmd_export,
        'import': cmd_import,
    }

    commands[args.command](args)


if __name__ == '__main__':
    main()